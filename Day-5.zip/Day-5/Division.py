try:
    list=[1,2,3,4,5]
    print(list[4])#
    list.append(123)
except Exception as e:
    print("Exception occurred:",e) 

try:
    pass
finally:
    print("Finally block executed")

try:
    pass
except:
    pass
finally:
    print("Finally block executed")
   
try:
    try:
        fnum=int(input("Enter first number: "))
        snum=int(input("Enter second number: "))
    except ValueError:
        print("Please enter a valid number")    
    result=fnum/snum#abnormal termination of program because of exception
    print("Division of two numbers is:",result)
    #close the file        
except ZeroDivisionError:
    print("You cannot divide a number by zero")
except ValueError:
    print("Please enter a valid number")
except IndexError:
    print("Invalid Index")
except Exception as e:
    print("Exception occurred:",e)       

finally:
    print("Finally block executed")     
print("remaining  10000 lines")
 