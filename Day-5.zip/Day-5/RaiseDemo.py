class InvalidCredentials(Exception):
    def __init__(self,message):
        self.message=message

username=input("Enter username: ")
password=input("Enter password: ")

if username=="admin" and password=="admin":
    print("Login successful")
else:
    raise InvalidCredentials("Invalid username or password")    
