def get_number():
    return int("sandeep")

def process_number():
    result=get_number()
    return result
try:
    process_number()
except ValueError:
    print("Please enter a valid number")