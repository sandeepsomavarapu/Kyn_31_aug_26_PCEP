def divide():
    return 10/0

def calculate():
    result = divide()
    print("Result is:", result)
try:
    calculate()    
except ZeroDivisionError:
    print("You cannot divide a number by zero")    