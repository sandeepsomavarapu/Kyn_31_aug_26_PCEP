def read_age():
    age=int(input("Enter your age: "))
    return age

def register_user():
    age=read_age()
    print(age)
try:
    register_user()
except ValueError:
    print("Please enter a valid number")
