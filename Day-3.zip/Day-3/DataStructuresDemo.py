#List Comprehension in Python
students=["ravi","priya","akash","naresh","suresh"]

print(students[0])  # Output: ravi
students.append("anita")  # Adding a new student to the list
print(students)  # Output: ['ravi', 'priya', 'akash', 'naresh', 'suresh', 'anita']
students.remove("naresh")  # Removing a student from the list
print(students)  # Output: ['ravi', 'priya', 'akash',

ravi_marks=[85, 90, 78, 92, 88]
ravi_marks.append(95)  # Adding a new mark to the list
print(ravi_marks[2])  # Output: 78
total = sum(ravi_marks)
print(total)  # Output: 433
print(max(ravi_marks))  # Output: 92
print(min(ravi_marks))  # Output: 78
print(len(ravi_marks))  # Output: 5
print(total / len(ravi_marks))  # Output: 86.6
print(sorted(ravi_marks))  # Output: [78, 85, 88, 90, 92]

#Tuples in Python
student_ids=(101, 102, 103, 104, 105)
print(student_ids[1])  # Output: 102
#student_ids.append(106)  # This will raise an AttributeError since tuples are immutable


skills=("Python","Java","C++","JavaScript")
print(skills)  # Output: C++

python_students={"ravi","priya","akash","naresh","suresh"}
print(python_students)  # Output: {'ravi', 'priya', 'akash', 'naresh', 'suresh'}

java_students={"akash","naresh","suresh","anita"}

print(python_students.intersection(java_students))  # Output: {'akash', 'naresh', 'suresh'}
print(python_students & java_students)  # Output: {'akash', 'naresh', 'suresh'}


print(python_students.union(java_students))  # Output: {'ravi', 'priya', 'akash', 'naresh', 'suresh', 'anita'}
print(python_students | java_students)  # Output: {'ravi', 'priya', 'akash', 'naresh', 'suresh', 'anita'}

print(python_students.difference(java_students))  # Output: {'ravi', 'priya'}

print(python_students - java_students)  # Output: {'ravi', 'priya'}

print(python_students ^ java_students)  # Output: {'ravi', 'priya', 'anita'}

print(python_students.symmetric_difference(java_students))  # Output: {'ravi', 'priya', 'anita'}


#Dictionaries in Python
student={
    "id":101,
    "name":"ravi",
    "age":20,
    "marks":
            {
            "maths":85,
            "science":90,
            "english":78
            }

        }
#print student info
print(student["name"])  # Output: ravi
print(student["age"])   # Output: 20
print(student["marks"]["maths"])  # Output: 85
ravi_marks=student.get("marks").values()
print(list(ravi_marks))  # Output: [85, 90, 78]
print(sum(ravi_marks))  # Output: 253


