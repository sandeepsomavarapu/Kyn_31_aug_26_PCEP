employees = [

{"id":101,"name":"Ravi","age":22,"department":"IT","salary":50000,
"skills":{"Python","Java","SQL"},
"projects":["ERP","CRM"],
"ratings":[80,85,90],
"basic_info":{"city":"Hyderabad","blood_group":"O+"}},

{"id":102,"name":"Mahesh","age":25,"department":"HR","salary":45000,
"skills":{"Excel","Recruitment","Communication"},
"projects":["Hiring"],
"ratings":[75,88,82],
"basic_info":{"city":"Bangalore","blood_group":"A+"}},

{"id":103,"name":"Kiran","age":24,"department":"IT","salary":55000,
"skills":{"Python","AWS","Linux"},
"projects":["Cloud Migration"],
"ratings":[90,91,92],
"basic_info":{"city":"Chennai","blood_group":"B+"}},

{"id":104,"name":"Anil","age":23,"department":"Finance","salary":48000,
"skills":{"Excel","Accounting","Tally"},
"projects":["Audit"],
"ratings":[78,80,85],
"basic_info":{"city":"Pune","blood_group":"AB+"}},

{"id":105,"name":"Sandeep","age":26,"department":"IT","salary":65000,
"skills":{"Python","Django","SQL"},
"projects":["E-Commerce"],
"ratings":[95,96,94],
"basic_info":{"city":"Hyderabad","blood_group":"O-"}},

{"id":106,"name":"Priya","age":24,"department":"Testing","salary":47000,
"skills":{"Selenium","Java","Manual Testing"},
"projects":["Automation"],
"ratings":[82,85,87],
"basic_info":{"city":"Vizag","blood_group":"A-"}},

{"id":107,"name":"Neha","age":27,"department":"IT","salary":70000,
"skills":{"React","NodeJS","MongoDB"},
"projects":["Web Portal"],
"ratings":[88,89,91],
"basic_info":{"city":"Hyderabad","blood_group":"B-"}},

{"id":108,"name":"Ramesh","age":22,"department":"Support","salary":38000,
"skills":{"Networking","Linux","Windows"},
"projects":["Infrastructure"],
"ratings":[70,72,75],
"basic_info":{"city":"Delhi","blood_group":"O+"}},

{"id":109,"name":"Harsha","age":25,"department":"IT","salary":60000,
"skills":{"Python","Flask","AWS"},
"projects":["Cloud App"],
"ratings":[90,88,92],
"basic_info":{"city":"Mumbai","blood_group":"A+"}},

{"id":110,"name":"Srinu","age":24,"department":"Testing","salary":50000,
"skills":{"Java","Selenium","API Testing"},
"projects":["Banking App"],
"ratings":[84,85,88],
"basic_info":{"city":"Chennai","blood_group":"B+"}},

{"id":111,"name":"Divya","age":23,"department":"HR","salary":46000,
"skills":{"Communication","Recruitment","Excel"},
"projects":["Campus Drive"],
"ratings":[80,83,85],
"basic_info":{"city":"Mysore","blood_group":"O+"}},

{"id":112,"name":"Pavan","age":28,"department":"IT","salary":80000,
"skills":{"Python","AI","Machine Learning"},
"projects":["Prediction Model"],
"ratings":[96,98,97],
"basic_info":{"city":"Hyderabad","blood_group":"AB+"}},

{"id":113,"name":"Manoj","age":27,"department":"Finance","salary":52000,
"skills":{"Accounting","Excel","Taxation"},
"projects":["Tax Filing"],
"ratings":[82,79,84],
"basic_info":{"city":"Delhi","blood_group":"O-"}},

{"id":114,"name":"Keerthi","age":25,"department":"IT","salary":68000,
"skills":{"Angular","NodeJS","MongoDB"},
"projects":["Customer Portal"],
"ratings":[90,92,91],
"basic_info":{"city":"Pune","blood_group":"A+"}},

{"id":115,"name":"Akash","age":22,"department":"Support","salary":40000,
"skills":{"Networking","Linux"},
"projects":["Server Upgrade"],
"ratings":[72,75,78],
"basic_info":{"city":"Nagpur","blood_group":"B+"}},

{"id":116,"name":"Swapna","age":24,"department":"Testing","salary":51000,
"skills":{"Automation","Python","Selenium"},
"projects":["Mobile App"],
"ratings":[88,86,90],
"basic_info":{"city":"Hyderabad","blood_group":"AB-"}},

{"id":117,"name":"Rohit","age":26,"department":"IT","salary":72000,
"skills":{"DevOps","Docker","Kubernetes"},
"projects":["CI/CD"],
"ratings":[94,93,95],
"basic_info":{"city":"Bangalore","blood_group":"O+"}},

{"id":118,"name":"Sneha","age":23,"department":"HR","salary":47000,
"skills":{"Recruitment","Excel","Training"},
"projects":["L&D"],
"ratings":[81,83,80],
"basic_info":{"city":"Hyderabad","blood_group":"B-"}},

{"id":119,"name":"Kumar","age":25,"department":"Finance","salary":55000,
"skills":{"Accounting","SAP","Excel"},
"projects":["ERP Finance"],
"ratings":[86,88,87],
"basic_info":{"city":"Chennai","blood_group":"O+"}},

{"id":120,"name":"Ajay","age":29,"department":"IT","salary":90000,
"skills":{"AI","Python","Data Science"},
"projects":["Analytics Platform"],
"ratings":[98,99,97],
"basic_info":{"city":"Hyderabad","blood_group":"A+"}}

]