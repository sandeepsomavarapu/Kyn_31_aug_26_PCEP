student=[{
"id":101,
"name":"ravi",
"age":20,
"courses": ["Python", "Java", "C++"],
"marks":[80, 85, 90, 78, 92],
"skills":{"Python","Java","C++","JavaScript"},
"basic_info":
            {
            "height":5.8,
            "weight":70,
            "blood_group":"O+"
            }
},
{"id":102,
"name":"mahesh",
"age":21,
"courses": ["Golang", "Java", "C++"],
"marks":[82, 88, 70, 85, 93],
"skills":{"Git","Java","Golang","JavaScript"},
"basic_info":
            {
            "height":5.6,
            "weight":79,
            "blood_group":"A+"
            }
}

]

print(student[1]["marks"][1])
print(student[0]["skills"])
#print student names
for s in student:
    sum_marks = sum(s["marks"])
    print(f"{s['name']}: {sum_marks}")
    