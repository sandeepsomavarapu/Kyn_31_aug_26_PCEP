x=12
y=20

print(x and y)
print(x or y)

print(True and False)#True
print(True or False)#True
print(not True)