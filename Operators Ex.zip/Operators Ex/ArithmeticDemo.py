#  +,-,*,/,%,//,**
a=10
b=2
print("a+b = ",a+b)#12
print("a-b = ",a-b)#8
print("a*b = ",a*b)#20
print("a/b = ",a/b)#5.0
print("a%b = ",a%b)#0
print("a//b = ",a//b)#  5   floor division
print("a**b =",a**b)# 100 Exponent or power operator

print(12//3.5)
print(10**3)