#>,<,>=,<=

a=10
b=20
print("a>b = ",a>b)#False
print("a<b = ",a<b)#True
print("a>=b = ",a>=b)#False
print("a<=b = ",a<=b)#True

print("sandeep">"sandeep")
print(10<20)
print(10<20<30)
print(10<20<30<40)
print(10<20<30<40>50)

print("sandeep"=="sandeep")
print(10!=20)

print(10==30==40)