#&,|,^,~,<<,>>

print(1 & 1)#1
print(1 | 0)#1
print(1 ^ 0)#1
print(1 ^ 1)#0
print(~5)
print(10>>2)
print(10<<2)
#1010