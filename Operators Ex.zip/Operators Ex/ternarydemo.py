#ternary or conditional operator

#syntax: x=firstvalue if condition else secondvalue

a,b=10,20
x="a is bigger" if a>b else "b is bigger"
print(x)

x,y,z=12,13,14

max=x if x>y and x>z else y if y>z else z

print(max)

a=10
b=20
print(a is not b)

