def greet():
    print("Hello, welcome to the calculator program!")
greet()
orgname="kyndryl"#global variable
def add_of_two_numbers(a,b):#parameters  local variables
    global age
    age=23#local variable
    print("add of two numbers is:",a+b)
    print("orgname is:",orgname)
    print("age is:",age)
      #True,False,None
def sub_of_two_numbers(a,b):
    global age
    print("age is:",age) #name error because age is local variable and it is not accessible outside the function
    print("orgname is:",orgname)
    result=a-b
    return result
    
def mul_of_two_numbers(a,b):
    print("mul of two numbers is:",a*b)
def div_of_two_numbers(a,b):
    print("div of two numbers is:",a/b)
def square_of_a_number(a):
    print("square of a number is:",a*a)

add_of_two_numbers(10,20)#arguments
add_of_two_numbers(30,20)
print(sub_of_two_numbers(10,20))
result=sub_of_two_numbers(30,20)
print("sub of two numbers is:",result)