fnum=int(input("Enter first number: "))
snum=int(input("Enter second number: "))
try:
    result=fnum/snum#abnormal termination of program because of exception
    print("Division of two numbers is:",result)
except ZeroDivisionError:
    print("You cannot divide a number by zero")
print("remaining  10000 lines")