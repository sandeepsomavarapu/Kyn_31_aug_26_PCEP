#positional arguments
def add(a,b):
    return a + b
print(add(10,20))

#keyword arguments
def sub(a,b):
    print("sub of two numbers is:",a-b)
sub(a=23,b=23)
sub(b=3,a=2)
#sub(10)

#default arguments
def mul(a,b=3):
    print("mul of two numbers is:",a*b)

mul(10,5)  # uses provided value of b
mul(10)     # uses default value of b
# mul(1,2,3,4)

#variable length arguments
def add(*args):
    total = 0
    for n in args:
        total += n
    print("sum of all numbers is:", total)

add(10, 20)
add(10, 20, 30)
add(10, 20, 30, 40)

#keyword variable length arguments
def display_info(**kwargs):
    for key, value in kwargs.items():
        print(f"{key}: {value}")

display_info(name="Alice", age=30, city="New York")